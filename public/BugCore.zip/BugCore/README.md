# BUGCORE - Enterprise Defect Tracking & Slack ChatOps Platform

**BUGCORE** (BugCore) is a modern, modular ASP.NET Core MVC defect tracking platform translated from the legacy BugCoreBT architecture. It features a dual-tier Slack ChatOps integration, role-based access control (RBAC), multi-project hierarchy management, and multi-channel webhook dispatching.

---

## 🚀 Quick Start Guide

### Default Administrator Credentials

| Role | Default Username | Default Password | Access & Permissions |
| :--- | :--- | :--- | :--- |
| **System Administrator** | `administrator` | `root` | Root governance, organization member provisioning, Slack ChatOps & channel routing |

> **🔐 Security & Access Governance:**
> * **No Public Registration**: Public self-registration and "Create Account" buttons are disabled by default.
> * **Admin-Only Provisioning**: Only the System Administrator can add new members to the organization via **User Accounts (`/Admin/Users`)**.
> * **Self-Service Password Management**: Every member (Administrator, Manager, Developer, Reporter, etc.) can update their personal password at any time via **Change Password (`/Account/ChangePassword`)**.
> * **Automatic Admin Session**: In the live preview environment, the Administrator session is active by default with zero login barriers on the main page.

---

## 🛡️ Dual-Tier Slack ChatOps Architecture (Zero Hardcoded Secrets)

BUGCORE isolates **Organization Governance** from **Individual User Actions** for maximum security, role-based authorization, and strict multi-tenant isolation. All bot tokens, signing secrets, and personal Slack Member IDs are dynamically bound through UI portals or environment variables — **nothing is hardcoded**.

### 1. ⚡ Individual User ChatOps Workbench (`/Slack`)
* **Individual Identity Binding**: Every member (Administrator, Manager, Developer, Reporter, etc.) links their personal Slack Member ID (`U...`) and username independently.
* **Personal Notification & DM Rules**: Choose minimum alert priority (All, High, Immediate), mute low priority alerts, and enable Direct Messages when a bug is assigned to you.
* **Role-Authorized Slash Commands (`/bug`)**:
  * `/bug report [summary]` — File defects directly from Slack (Reporter, Developer, Manager, Admin).
  * `/bug resolve [BUG-ID]` — Resolve defects directly from Slack (Developer, Manager, Admin).
  * `/bug assign [BUG-ID]` — Self-assign defects (Developer, Manager, Admin).
  * `/bug search [query]` & `/bug my-tickets` — Query personal and team defect queues (All roles).
  * `/bug broadcast [msg]` — Organization announcements across channels (Admin only).
* **Interactive Command Simulator**: Test and verify your role's permitted slash commands right from the web console.

### 2. 🔐 Admin Governance Portal (`/Slack/Admin`)
* **Organization Credentials Configuration**: Enter your Workspace Bot OAuth Token (`xoxb-...`), HMAC-SHA256 Signing Secret, App ID, and default broadcast channel with zero hardcoded defaults.
* **Admin Organization Identity**: Link the Administrator's Slack account to act as the authorized sender for organization alerts.
* **Broadcast & Alert Dispatcher**: Send instant emergency alerts or company-wide announcements directly into targeted Slack channels with live audit logging.
* **Project-to-Channel Routing Matrix**: Map individual BUGCORE projects to specific team Slack channels (`#dev-alerts`, `#mobile-bugs`).
* **Security & HMAC Verification**: Validate incoming webhooks using HMAC-SHA256 signature verification.

---

## 💻 Running Locally

### Running with .NET 8 SDK (Local Machine)
If you have the .NET 8 SDK installed on your machine:
```bash
cd BugCore
dotnet restore
dotnet build
dotnet run --project src/BugCore.Web
```
The application will launch on `http://localhost:5000`.

### Running in Preview Sandbox (Node.js Engine)
In the preview environment, the application runs on **Port 3000** (`npm start`), serving the complete UI layout, role switcher, Slack ChatOps workbench, and API endpoints.

---

## 🌐 Production Deployment Guide for Organizations

When deploying BUGCORE for production use in your organization, follow these deployment strategies:

### Option 1: Containerized Deployment (Docker / AWS ECS / Google Cloud Run / Azure Container Apps)
BUGCORE is fully containerizable with a standard multi-stage .NET 8 Dockerfile:

```dockerfile
# Build Stage
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /app
COPY BugCore/ .
RUN dotnet restore src/BugCore.Web/BugCore.Web.csproj
RUN dotnet publish src/BugCore.Web/BugCore.Web.csproj -c Release -o /out

# Runtime Stage
FROM mcr.microsoft.com/dotnet/aspnet:8.0
WORKDIR /app
COPY --from=build /out .
EXPOSE 8080
ENV ASPNETCORE_URLS=http://+:8080
ENTRYPOINT ["dotnet", "BugCore.Web.dll"]
```

### Option 2: Azure App Service or Windows Server IIS
* **Azure App Service**: Deploy `BugCore.Web.csproj` directly via GitHub Actions or Azure DevOps pipeline targeting `.NET 8 (LTS)`.
* **On-Premises IIS**: Install the [.NET Core Hosting Bundle](https://dotnet.microsoft.com/download/dotnet/8.0) on Windows Server, configure an IIS Application Pool set to **No Managed Code**, and point the site physical path to the published folder.

### Option 3: Linux VM (Ubuntu / Debian + Nginx Reverse Proxy)
1. Install `.NET 8 Runtime` on your server.
2. Publish output: `dotnet publish -c Release -o /var/www/bugcore`.
3. Configure `systemd` service (`/etc/systemd/system/bugcore.service`):
   ```ini
   [Unit]
   Description=BUGCORE ASP.NET Core Web App
   [Service]
   WorkingDirectory=/var/www/bugcore
   ExecStart=/usr/bin/dotnet /var/www/bugcore/BugCore.Web.dll
   Restart=always
   Environment=ASPNETCORE_ENVIRONMENT=Production
   [Install]
   WantedBy=multi-user.target
   ```
4. Setup **Nginx** reverse proxy to forward HTTPS traffic to `http://localhost:5000` and enable Let's Encrypt SSL.

---

## ⚙️ Organization Environment Variables & Configuration

For production deployment, override default settings in `appsettings.Production.json` or system Environment Variables:

| Environment Variable | Description | Example |
| :--- | :--- | :--- |
| `ConnectionStrings__DefaultConnection` | PostgreSQL / SQL Server Connection String | `Server=db.org.com;Database=BugcoreDb;User Id=app;Password=...` |
| `Slack__BotToken` | Organization Central Slack Bot User OAuth Token | `YOUR_SLACK_BOT_TOKEN_HERE` |
| `Slack__SigningSecret` | Slack Signing Secret for HMAC Verification | `e123456789abcdef...` |
| `Slack__AppId` | Organization Slack App ID | `A08SLACKAPPID` |
| `GitHub__WebhookSecret` | HMAC secret for GitHub Commit Linker | `gh_secret_123` |

---

## 🔐 Organization Slack App Setup Checklist

1. **Create Slack App**: Visit [api.slack.com/apps](https://api.slack.com/apps) and click **Create New App** -> **From an app manifest**.
2. **Paste App Manifest**: Copy the generated App Manifest JSON from BUGCORE Admin Governance (`/Slack/Admin`).
3. **Install to Workspace**: Click **Install to Workspace** and grant channel permissions.
4. **Copy Bot Token & Signing Secret**: Save Bot User OAuth Token and Signing Secret into your production deployment environment variables.
5. **Verify HTTPS**: Ensure your deployed URL has a valid SSL certificate (e.g., `https://bugcore.yourcompany.com`) as required by Slack for event subscriptions and Slash commands.

---

## 🤝 Need Help or Support?
* **Report a bug**: Navigate to `/Issue/Create` or type `/bug report` in Slack.
* **Manage channels**: Access `/Slack/Admin` as an Administrator.
* **Link Slack account**: Access `/Slack` as a Developer.
